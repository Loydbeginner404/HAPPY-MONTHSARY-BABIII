const slides = document.querySelectorAll(".slide");
const counter = document.getElementById("counter");
const caption = document.getElementById("caption");
const title = document.getElementById("title");
const text = document.getElementById("text");
const fill = document.getElementById("fill");
const timelineText = document.getElementById("timelineText");
const music = document.getElementById("music");
const musicBtn = document.getElementById("musicBtn");
const finalBox = document.getElementById("final");

const captions = [
  "Our favorite memory",
  "Your beautiful smile",
  "Simple moments",
  "My favorite person",
  "Our story",
  "My peace",
  "My promise",
  "Forever ikaw"
];

const titles = [
  "To my babiii",
  "Your smile",
  "Small moments",
  "Favorite person",
  "Our story",
  "My peace",
  "Promise ko",
  "Forever ikaw"
];

const messages = [
  "Happy Monthsary, babiii ko. Another month na naman na ikaw pa rin ang pinaka special sakin.",
  "Yung ngiti mo yung isa sa pinaka gusto kong makita. Kahit simple lang, gumagaan araw ko.",
  "Hindi kailangan laging engrande. Basta ikaw kasama ko, special na agad yung moment.",
  "Sa dami ng tao, ikaw yung lagi kong pipiliin at gustong alagaan.",
  "Bawat buwan na lumilipas, mas lalo kong nararamdaman na ikaw yung gusto kong makasama.",
  "Ikaw yung pahinga ko sa magulong araw. Thank you kasi andyan ka.",
  "Pipiliin kita sa masayang araw, sa mahirap na araw, at sa lahat ng pangarap natin.",
  "Sobrang mahal na mahal kita, babiii ko. Happy Monthsary sa atin."
];

let index = 0;
let timer = null;

function typeMessage(message) {
  clearInterval(timer);
  text.textContent = "";
  let i = 0;
  
  timer = setInterval(() => {
    text.textContent += message[i] || "";
    i++;
    
    if (i >= message.length) {
      clearInterval(timer);
    }
  }, 18);
}

function showSlide() {
  slides.forEach(slide => slide.classList.remove("active"));
  slides[index].classList.add("active");
  
  caption.textContent = captions[index];
  title.textContent = titles[index];
  counter.textContent = `${index + 1} / ${slides.length}`;
  timelineText.textContent = `Memory ${index + 1} of ${slides.length}`;
  fill.style.width = `${((index + 1) / slides.length) * 100}%`;
  
  typeMessage(messages[index]);
}

function nextSlide() {
  index = (index + 1) % slides.length;
  showSlide();
  burstHearts(8);
}

function prevSlide() {
  index = (index - 1 + slides.length) % slides.length;
  showSlide();
  burstHearts(8);
}

function safeTap(id, action) {
  const button = document.getElementById(id);
  
  button.addEventListener("click", action);
  button.addEventListener("touchend", function(e) {
    e.preventDefault();
    action();
  }, { passive: false });
}

safeTap("nextBtn", nextSlide);
safeTap("prevBtn", prevSlide);

safeTap("surpriseBtn", () => {
  finalBox.classList.add("show");
  burstHearts(70);
});

safeTap("closeFinal", () => {
  finalBox.classList.remove("show");
});

safeTap("heartsBtn", () => {
  burstHearts(40);
});

safeTap("musicBtn", () => {
  music.play()
    .then(() => {
      musicBtn.textContent = "MUSIC PLAYING";
    })
    .catch(() => {
      musicBtn.textContent = "ADD music.mp3";
    });
});

function heart() {
  const h = document.createElement("div");
  h.className = "heart";
  h.textContent = ["❤", "💗", "💕", "💖"][Math.floor(Math.random() * 4)];
  h.style.left = Math.random() * 100 + "vw";
  h.style.bottom = "-30px";
  h.style.animationDuration = 3 + Math.random() * 3 + "s";
  
  document.body.appendChild(h);
  
  setTimeout(() => {
    h.remove();
  }, 6500);
}

function burstHearts(count) {
  for (let i = 0; i < count; i++) {
    setTimeout(heart, i * 35);
  }
}

setInterval(heart, 1200);
showSlide();